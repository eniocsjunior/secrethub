# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['secrethub']

package_data = \
{'': ['*']}

install_requires = \
['argon2-cffi>=23.1.0,<24.0.0', 'cryptography>=44.0.0,<45.0.0']

setup_kwargs = {
    'name': 'secrethub',
    'version': '0.1.0',
    'description': '',
    'long_description': "# Secrethub\nCreation and verification of cryptographic keys.\n\n## How to use\n\nTo instantiate a Secret class you must first have a key:\n```python\n>>> from secrethub import Secret\n>>> new_key = Secret.new\n>>> new_secret\n'UEGVN46SwIOyQCneO-sudqDRlqbM3Td8ygozeoWqY2A='\n>>> secret = Secret(key=new_key)\n```\nNow you can encrypt and decrypt messages:\n```python\n>>> message = 'Hello Secret'\n>>> encrypted_message = secret.encrypt(message)\n>>> encrypted_message\n'gAAAAABnVgxFcin82sXSGvZH5Uwia4KDewcK3xk5Kbwiv2Uk95GLXwj0pVxReoQi04M9SJZ6yiYxGp8e6o8j9k0DiBWdEZWOLg=='\n>>> secret.decrypt(encrypted_message)\n'Hello Secret'\n```\nYou can also hash passwords and verify them:\n```python\n>>> password = '57r0n6p4$5W0rD4n07h1n6'\n>>> hashed_password = secret.hash(password)\n>>> hashed_password\n'$argon2id$v=19$m=65536,t=3,p=4$JB0aad1g1h01VrUK46iv2w$/8Sw0taHXdVi2tBFA4hRaBHPcx8JtJ7Qq71X46TWpP4'\n>>> secret.verify(hashed_password, password)\nTrue\n```\nYou can also use this module via the command line:\n```bash\n$ python -m secrethub\n\nHow to use:\npython -m secrethub [option]\n\nOptions:\nnew                     Generate new cryptographic key.\nencrypt [message]       Encrypt message\ndecrypt [key]           Decrypt key\nhash [password]\nverify [hash] [password]\n\n$\n```\n",
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
