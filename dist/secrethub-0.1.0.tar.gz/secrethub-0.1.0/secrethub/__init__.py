from secrethub.secrets import Secret

__all__ = [
    'Secret'
]
